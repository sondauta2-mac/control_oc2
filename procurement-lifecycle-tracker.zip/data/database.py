# -*- coding: utf-8 -*-
"""
Procurement Lifecycle Tracker - Database Persistence
Handles JSON-based persistence to disk (Option B) and seeds demo records.
"""

import os
import json
from datetime import datetime, date
import config


def json_serial(obj):
    """JSON serializer for objects not serializable by default json code (e.g. date)"""
    if isinstance(obj, (datetime, date)):
        return obj.isoformat()
    raise TypeError(f"Type {type(obj)} not serializable")


def seed_mock_data():
    """
    Returns a default list of procurement requests to seed the database on first run.
    Dates are structured backward from today (2026-07-13) to represent a realistic history.
    """
    return [
        {
            "id": "RQ-1001",
            "title": "Servidores Cloud AWS para Migración Core",
            "requestor": "Iván Ríos",
            "area": "TI & Sistemas",
            "amount": 15500.00,
            "current_milestone": config.MILESTONE_5_INVOICED,
            "created_at": "2026-06-01",
            "pr_number": "PR-88271",
            "po_number": "PO-99102",
            "invoice_number": "INV-AWS-5542",
            "history": [
                {
                    "milestone": config.MILESTONE_1_SUBMITTED,
                    "updated_at": "2026-06-01",
                    "updated_by": "Iván Ríos",
                    "comments": "Solicitud inicial para migración de servidores core a nube AWS."
                },
                {
                    "milestone": config.MILESTONE_2_COMMITTEE_APPROVED,
                    "updated_at": "2026-06-03",
                    "updated_by": "Comité de Compras",
                    "comments": "Monto dentro del presupuesto anual. Aprobado por unanimidad."
                },
                {
                    "milestone": config.MILESTONE_3_PR_CREATED,
                    "updated_at": "2026-06-05",
                    "updated_by": "Iván Ríos",
                    "comments": "PR creado correctamente en SAP Ariba."
                },
                {
                    "milestone": config.MILESTONE_4_PO_ISSUED,
                    "updated_at": "2026-06-08",
                    "updated_by": "Sistemas de Compras",
                    "comments": "PO liberada y enviada al proveedor AWS."
                },
                {
                    "milestone": config.MILESTONE_5_INVOICED,
                    "updated_at": "2026-06-12",
                    "updated_by": "Finanzas Cuentas por Pagar",
                    "comments": "Factura recibida, cuadrada con la PO y pagada. Ciclo finalizado."
                }
            ]
        },
        {
            "id": "RQ-1002",
            "title": "Licencias de Software de Diseño CAD",
            "requestor": "María López",
            "area": "Operaciones",
            "amount": 8400.00,
            "current_milestone": config.MILESTONE_4_PO_ISSUED,
            "created_at": "2026-06-25",
            "pr_number": "PR-88390",
            "po_number": "PO-99211",
            "invoice_number": "",
            "history": [
                {
                    "milestone": config.MILESTONE_1_SUBMITTED,
                    "updated_at": "2026-06-25",
                    "updated_by": "María López",
                    "comments": "Requerido para el nuevo equipo de ingenieros de manufactura."
                },
                {
                    "milestone": config.MILESTONE_2_COMMITTEE_APPROVED,
                    "updated_at": "2026-06-28",
                    "updated_by": "Comité de Compras",
                    "comments": "Aprobado con vigencia de 12 meses."
                },
                {
                    "milestone": config.MILESTONE_3_PR_CREATED,
                    "updated_at": "2026-07-01",
                    "updated_by": "María López",
                    "comments": "PR registrado en Ariba."
                },
                {
                    "milestone": config.MILESTONE_4_PO_ISSUED,
                    "updated_at": "2026-07-04",
                    "updated_by": "Sistemas de Compras",
                    "comments": "PO liberada y despachada."
                }
            ]
        },
        {
            "id": "RQ-1003",
            "title": "Renovación de Soporte SmartNet Cisco",
            "requestor": "Iván Ríos",
            "area": "TI & Sistemas",
            "amount": 12000.00,
            "current_milestone": config.MILESTONE_3_PR_CREATED,
            "created_at": "2026-07-06",
            "pr_number": "PR-88450",
            "po_number": "",
            "invoice_number": "",
            "history": [
                {
                    "milestone": config.MILESTONE_1_SUBMITTED,
                    "updated_at": "2026-07-06",
                    "updated_by": "Iván Ríos",
                    "comments": "Garantía anual de switches del datacenter principal."
                },
                {
                    "milestone": config.MILESTONE_2_COMMITTEE_APPROVED,
                    "updated_at": "2026-07-08",
                    "updated_by": "Comité de Compras",
                    "comments": "Crítico para operación. Aprobado de inmediato."
                },
                {
                    "milestone": config.MILESTONE_3_PR_CREATED,
                    "updated_at": "2026-07-11",
                    "updated_by": "Iván Ríos",
                    "comments": "PR ingresado. Esperando emisión de PO por compras."
                }
            ]
        },
        {
            "id": "RQ-1004",
            "title": "Dispositivos Móviles Rugerizados de Almacén",
            "requestor": "Carlos Gómez",
            "area": "Operaciones",
            "amount": 4500.00,
            "current_milestone": config.MILESTONE_2_COMMITTEE_APPROVED,
            "created_at": "2026-07-01", # Will flag as delayed for milestone 2_COMMITTEE_APPROVED (SLA target is 5 days, today is July 13th)
            "pr_number": "",
            "po_number": "",
            "invoice_number": "",
            "history": [
                {
                    "milestone": config.MILESTONE_1_SUBMITTED,
                    "updated_at": "2026-07-01",
                    "updated_by": "Carlos Gómez",
                    "comments": "Sustitución de colectores dañados."
                },
                {
                    "milestone": config.MILESTONE_2_COMMITTEE_APPROVED,
                    "updated_at": "2026-07-04",
                    "updated_by": "Comité de Compras",
                    "comments": "Aprobada la compra de 5 unidades."
                }
            ]
        },
        {
            "id": "RQ-1005",
            "title": "Consultoría y Auditoría de Seguridad Perimetral",
            "requestor": "Iván Ríos",
            "area": "TI & Sistemas",
            "amount": 22000.00,
            "current_milestone": config.MILESTONE_1_SUBMITTED,
            "created_at": "2026-07-12",
            "pr_number": "",
            "po_number": "",
            "invoice_number": "",
            "history": [
                {
                    "milestone": config.MILESTONE_1_SUBMITTED,
                    "updated_at": "2026-07-12",
                    "updated_by": "Iván Ríos",
                    "comments": "Análisis externo de vulnerabilidades e intrusión perimetral."
                }
            ]
        }
    ]


def ensure_db_exists():
    """Ensure database directory and JSON file exist, seeding if missing."""
    if not os.path.exists(config.DATA_DIR):
        os.makedirs(config.DATA_DIR, exist_ok=True)
        
    if not os.path.exists(config.DATABASE_FILE) or os.path.getsize(config.DATABASE_FILE) == 0:
        data = seed_mock_data()
        # Write directly to avoid calling save_db which would call ensure_db_exists
        with open(config.DATABASE_FILE, "w", encoding="utf-8") as f:
            json.dump(data, f, default=json_serial, indent=4, ensure_ascii=False)


def load_db():
    """Load all requests from JSON file."""
    ensure_db_exists()
    try:
        with open(config.DATABASE_FILE, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception as e:
        # Fallback to seed data on error
        return seed_mock_data()


def save_db(data):
    """Save requests list to JSON file."""
    # Just make sure the directory exists, don't call ensure_db_exists() which could trigger loop
    if not os.path.exists(config.DATA_DIR):
        os.makedirs(config.DATA_DIR, exist_ok=True)
    with open(config.DATABASE_FILE, "w", encoding="utf-8") as f:
        json.dump(data, f, default=json_serial, indent=4, ensure_ascii=False)


def get_all_requests():
    """Get all requests."""
    return load_db()


def get_request_by_id(req_id):
    """Retrieve a single request by ID."""
    requests = load_db()
    for r in requests:
        if r["id"].strip().upper() == req_id.strip().upper():
            return r
    return None


def create_request(title, requestor, area, amount, comments, creator):
    """Create a new procurement request at milestone 1_SUBMITTED."""
    requests = load_db()
    
    # Generate sequential ID (e.g. RQ-1006)
    existing_ids = []
    for r in requests:
        id_str = r["id"]
        if id_str.startswith("RQ-"):
            try:
                num = int(id_str.split("-")[1])
                existing_ids.append(num)
            except ValueError:
                pass
                
    next_num = max(existing_ids) + 1 if existing_ids else 1001
    new_id = f"RQ-{next_num}"
    
    today_str = date.today().isoformat()
    
    new_request = {
        "id": new_id,
        "title": title,
        "requestor": requestor,
        "area": area,
        "amount": float(amount),
        "current_milestone": config.MILESTONE_1_SUBMITTED,
        "created_at": today_str,
        "pr_number": "",
        "po_number": "",
        "invoice_number": "",
        "history": [
            {
                "milestone": config.MILESTONE_1_SUBMITTED,
                "updated_at": today_str,
                "updated_by": creator,
                "comments": comments
            }
        ]
    }
    
    requests.append(new_request)
    save_db(requests)
    return new_request


def update_request_milestone(req_id, next_milestone, updated_by, comments, pr_num="", po_num="", inv_num=""):
    """
    Advance a request to its next milestone and update Ariba codes if supplied.
    """
    requests = load_db()
    updated_req = None
    
    for r in requests:
        if r["id"] == req_id:
            r["current_milestone"] = next_milestone
            
            # Update values if provided
            if pr_num:
                r["pr_number"] = pr_num
            if po_num:
                r["po_number"] = po_num
            if inv_num:
                r["invoice_number"] = inv_num
                
            # Log transition to history
            history_entry = {
                "milestone": next_milestone,
                "updated_at": date.today().isoformat(),
                "updated_by": updated_by,
                "comments": comments
            }
            r["history"].append(history_entry)
            updated_req = r
            break
            
    if updated_req:
        save_db(requests)
        
    return updated_req
