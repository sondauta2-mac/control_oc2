# -*- coding: utf-8 -*-
"""
Procurement Lifecycle Tracker - Authentication Module
Manages session roles and mock users for the POC.
"""

import streamlit as st
import config

# Define list of mock users for the POC demo
MOCK_USERS = [
    {
        "username": "irios",
        "name": "Iván Ríos",
        "role": config.ROLE_SOLICITANTE,
        "email": "ivan.rios@empresa.com",
        "area": "TI & Sistemas"
    },
    {
        "username": "comite_proc",
        "name": "Comité de Compras",
        "role": config.ROLE_COMITE,
        "email": "comite.compras@empresa.com",
        "area": "Finanzas & Compras"
    },
    {
        "username": "admin_sys",
        "name": "Administrador General",
        "role": config.ROLE_ADMIN,
        "email": "admin@empresa.com",
        "area": "Operaciones"
    }
]


def init_session_state():
    """
    Initialize all mandatory st.session_state variables if not already set.
    """
    if "user_role" not in st.session_state:
        # Default to Iván Ríos / Solicitante
        st.session_state.user_role = config.ROLE_SOLICITANTE
        
    if "current_user" not in st.session_state:
        st.session_state.current_user = MOCK_USERS[0]
        
    if "current_search_query" not in st.session_state:
        st.session_state.current_search_query = ""
        
    if "selected_request_details" not in st.session_state:
        st.session_state.selected_request_details = None


def set_user_session(user_dict):
    """
    Set current user and corresponding role in the session state.
    """
    st.session_state.current_user = user_dict
    st.session_state.user_role = user_dict["role"]
    st.success(f"Sesión iniciada como: **{user_dict['name']}** ({user_dict['role']})")


def get_current_user():
    """
    Return current authenticated user dictionary.
    """
    init_session_state()
    return st.session_state.current_user


def get_current_role():
    """
    Return current session user role.
    """
    init_session_state()
    return st.session_state.user_role
