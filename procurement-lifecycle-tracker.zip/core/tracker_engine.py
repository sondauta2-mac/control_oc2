# -*- coding: utf-8 -*-
"""
Procurement Lifecycle Tracker - Tracker Engine
Handles SLA, milestone transition logs, business days calculation, and KPI aggregation.
"""

from datetime import datetime, date
import pandas as pd
import config


def parse_date(date_val):
    """
    Safely parse a date value (string, date, or datetime) into a standard datetime.date object.
    """
    if not date_val:
        return None
    if isinstance(date_val, (date, datetime)):
        # If it's a datetime, extract date portion
        if isinstance(date_val, datetime):
            return date_val.date()
        return date_val
    if isinstance(date_val, str):
        # Strip timestamp part if present
        date_str = date_val.split("T")[0].split(" ")[0].strip()
        try:
            return datetime.strptime(date_str, "%Y-%m-%d").date()
        except ValueError:
            try:
                return datetime.strptime(date_str, "%d/%m/%Y").date()
            except ValueError:
                return None
    return None


def calculate_business_days(start_date, end_date):
    """
    Calculate the number of business days (Mon-Fri) between start_date and end_date (inclusive).
    Uses pandas bdate_range for accuracy.
    """
    start = parse_date(start_date)
    end = parse_date(end_date)
    
    if not start or not end:
        return 0
    
    if start > end:
        # If dates are reversed, return negative business days
        try:
            bdays = len(pd.bdate_range(start=end, end=start))
            return -bdays
        except Exception:
            return 0
            
    try:
        # bdate_range includes both start and end if they are business days
        bdays = len(pd.bdate_range(start=start, end=end))
        return bdays
    except Exception:
        # Fallback simple business days calculation if pandas fails
        day_count = 0
        current = start
        while current <= end:
            if current.weekday() < 5:  # Mon-Fri
                day_count += 1
            from datetime import timedelta
            current += timedelta(days=1)
        return day_count


def get_next_milestone(current_milestone):
    """
    Returns the next milestone in the sequential flow, or None if already in final milestone.
    """
    if current_milestone not in config.MILESTONES:
        return None
    idx = config.MILESTONES.index(current_milestone)
    if idx < len(config.MILESTONES) - 1:
        return config.MILESTONES[idx + 1]
    return None


def get_prev_milestone(current_milestone):
    """
    Returns the previous milestone in the sequential flow, or None if in the first milestone.
    """
    if current_milestone not in config.MILESTONES:
        return None
    idx = config.MILESTONES.index(current_milestone)
    if idx > 0:
        return config.MILESTONES[idx - 1]
    return None


def evaluate_sla(milestone, start_date, end_date=None):
    """
    Evaluate the SLA performance for a specific milestone.
    - milestone: the milestone being evaluated
    - start_date: date when the milestone was entered
    - end_date: date when the milestone was exited (defaults to today if still active)
    
    Returns a dict with SLA details.
    """
    target = config.SLA_TARGETS.get(milestone, 0)
    end = end_date if end_date else date.today()
    
    days_spent = calculate_business_days(start_date, end)
    # Subtract 1 if start and end are same day, or make it at least 0
    days_spent = max(0, days_spent - 1) if start_date == end else max(0, days_spent)
    
    is_breached = days_spent > target if target > 0 else False
    
    return {
        "milestone": milestone,
        "label": config.MILESTONE_LABELS.get(milestone, milestone),
        "target_days": target,
        "days_spent": days_spent,
        "status": "Vencido (Breached)" if is_breached else "A Tiempo (On Time)",
        "is_breached": is_breached,
        "remaining_days": max(0, target - days_spent) if not is_breached else 0
    }


def analyze_request_sla(request):
    """
    Analyze all SLA transitions and current status of a single procurement request.
    """
    history = request.get("history", [])
    current_milestone = request.get("current_milestone", config.MILESTONE_1_SUBMITTED)
    
    # Sort history chronologically
    sorted_history = sorted(
        [h for h in history if parse_date(h.get("updated_at")) is not None],
        key=lambda x: parse_date(x.get("updated_at"))
    )
    
    milestone_dates = {}
    for hist in sorted_history:
        m = hist.get("milestone")
        dt = parse_date(hist.get("updated_at"))
        if m and dt:
            # Keep the first time we transitioned into this milestone
            if m not in milestone_dates:
                milestone_dates[m] = dt

    timeline = []
    # Evaluate transitions
    for i in range(len(config.MILESTONES)):
        m = config.MILESTONES[i]
        if m not in milestone_dates:
            continue
            
        start_dt = milestone_dates[m]
        
        # Find when it moved to the next milestone
        next_m = None
        next_dt = None
        for j in range(i + 1, len(config.MILESTONES)):
            candidate = config.MILESTONES[j]
            if candidate in milestone_dates:
                next_m = candidate
                next_dt = milestone_dates[candidate]
                break
                
        if next_dt:
            # Completed transition
            sla_info = evaluate_sla(m, start_dt, next_dt)
            timeline.append(sla_info)
        elif m == current_milestone and m != config.MILESTONE_5_INVOICED:
            # Active, not completed milestone
            sla_info = evaluate_sla(m, start_dt, date.today())
            timeline.append(sla_info)
            
    # Check if currently delayed
    current_sla = None
    is_delayed = False
    if current_milestone != config.MILESTONE_5_INVOICED:
        current_start_date = milestone_dates.get(current_milestone)
        if current_start_date:
            current_sla = evaluate_sla(current_milestone, current_start_date, date.today())
            is_delayed = current_sla["is_breached"]
            
    # Total cycle time
    total_days = 0
    start_all = milestone_dates.get(config.MILESTONE_1_SUBMITTED)
    if start_all:
        end_all = milestone_dates.get(config.MILESTONE_5_INVOICED, date.today())
        total_days = calculate_business_days(start_all, end_all)

    return {
        "request_id": request.get("id"),
        "current_milestone": current_milestone,
        "is_delayed": is_delayed,
        "current_sla": current_sla,
        "timeline": timeline,
        "total_cycle_days": total_days,
        "milestone_dates": milestone_dates
    }


def calculate_dashboard_kpis(all_requests):
    """
    Calculate aggregate KPIs for the main dashboard view.
    - Total Requests
    - Active Requests (not INVOICED)
    - Delayed Active Requests
    - Completed Requests (INVOICED)
    - Average total cycle time for completed requests
    - Distribution of requests across milestones
    - SLA breach percentage
    """
    df_reqs = pd.DataFrame(all_requests) if all_requests else pd.DataFrame()
    
    kpis = {
        "total_requests": len(all_requests),
        "active_requests": 0,
        "delayed_active_requests": 0,
        "completed_requests": 0,
        "sla_on_time_percentage": 100.0,
        "avg_cycle_days": 0.0,
        "milestone_distribution": {m: 0 for m in config.MILESTONES},
        "by_area": {},
        "alerts": []
    }
    
    if df_reqs.empty:
        return kpis
        
    analyses = [analyze_request_sla(r) for r in all_requests]
    
    active_count = 0
    delayed_active_count = 0
    completed_count = 0
    completed_cycles = []
    
    for r, ana in zip(all_requests, analyses):
        m = r.get("current_milestone")
        if m in kpis["milestone_distribution"]:
            kpis["milestone_distribution"][m] += 1
            
        area = r.get("area", "Sin Área")
        kpis["by_area"][area] = kpis["by_area"].get(area, 0) + 1
            
        if m == config.MILESTONE_5_INVOICED:
            completed_count += 1
            completed_cycles.append(ana["total_cycle_days"])
        else:
            active_count += 1
            if ana["is_delayed"]:
                delayed_active_count += 1
                # Generate an alert for delayed request
                kpis["alerts"].append({
                    "id": r.get("id"),
                    "title": r.get("title"),
                    "requestor": r.get("requestor"),
                    "current_milestone_label": config.MILESTONE_LABELS.get(m, m),
                    "days_spent": ana["current_sla"]["days_spent"] if ana["current_sla"] else 0,
                    "target_days": ana["current_sla"]["target_days"] if ana["current_sla"] else 0
                })
                
    kpis["active_requests"] = active_count
    kpis["delayed_active_requests"] = delayed_active_count
    kpis["completed_requests"] = completed_count
    
    if completed_cycles:
        kpis["avg_cycle_days"] = float(pd.Series(completed_cycles).mean())
        
    # Calculate on-time SLA rate of active + completed requests
    # Active SLA breach occurs if currently delayed. Completed breach occurs if any transition in timeline breached.
    total_evaluated_transitions = 0
    breached_transitions = 0
    
    for ana in analyses:
        for t in ana["timeline"]:
            total_evaluated_transitions += 1
            if t["is_breached"]:
                breached_transitions += 1
                
    if total_evaluated_transitions > 0:
        kpis["sla_on_time_percentage"] = float(100.0 * (1.0 - breached_transitions / total_evaluated_transitions))
    else:
        kpis["sla_on_time_percentage"] = 100.0
        
    return kpis
