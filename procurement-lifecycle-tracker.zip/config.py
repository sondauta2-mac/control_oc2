# -*- coding: utf-8 -*-
"""
Procurement Lifecycle Tracker - Config File
Stores system constants, visual preferences, and targets.
"""

import os

# --- SYSTEM METADATA ---
APP_NAME = "Procurement Lifecycle Tracker"
APP_SUBTITLE = "Agente de Visibilidad de Compras"
SPOC = "Iván Ríos"

# --- USER ROLES ---
ROLE_ADMIN = "Admin"
ROLE_SOLICITANTE = "Solicitante"
ROLE_COMITE = "Comite"

USER_ROLES = [ROLE_SOLICITANTE, ROLE_COMITE, ROLE_ADMIN]
DEFAULT_ROLE = ROLE_SOLICITANTE

# --- MILESTONES (FLUX SEQUENTIAL) ---
MILESTONE_1_SUBMITTED = "1_SUBMITTED"
MILESTONE_2_COMMITTEE_APPROVED = "2_COMMITTEE_APPROVED"
MILESTONE_3_PR_CREATED = "3_PR_CREATED"
MILESTONE_4_PO_ISSUED = "4_PO_ISSUED"
MILESTONE_5_INVOICED = "5_INVOICED"

MILESTONES = [
    MILESTONE_1_SUBMITTED,
    MILESTONE_2_COMMITTEE_APPROVED,
    MILESTONE_3_PR_CREATED,
    MILESTONE_4_PO_ISSUED,
    MILESTONE_5_INVOICED
]

MILESTONE_LABELS = {
    MILESTONE_1_SUBMITTED: "Presentada al Comité",
    MILESTONE_2_COMMITTEE_APPROVED: "Aprobada por Comité",
    MILESTONE_3_PR_CREATED: "PR Creado (Ariba)",
    MILESTONE_4_PO_ISSUED: "PO Liberada (Ariba)",
    MILESTONE_5_INVOICED: "Facturado (Cerrado)"
}

MILESTONE_DESCRIPTIONS = {
    MILESTONE_1_SUBMITTED: "La solicitud de compra ha sido creada y enviada al comité para su respectiva aprobación.",
    MILESTONE_2_COMMITTEE_APPROVED: "El comité evaluó y aprobó la solicitud. Lista para iniciar creación de PR en SAP Ariba.",
    MILESTONE_3_PR_CREATED: "El usuario solicitante registró la Solicitud de Pedido (PR) en Ariba de forma exitosa.",
    MILESTONE_4_PO_ISSUED: "La Orden de Compra (PO) ha sido liberada por compras en Ariba y enviada al proveedor.",
    MILESTONE_5_INVOICED: "Se recibió la factura del proveedor y fue registrada. El ciclo de vida de compra está cerrado."
}

# Tailwind / Streamlit Hex Colors for Milestones
MILESTONE_COLORS = {
    MILESTONE_1_SUBMITTED: "#3B82F6",         # Blue
    MILESTONE_2_COMMITTEE_APPROVED: "#8B5CF6", # Purple
    MILESTONE_3_PR_CREATED: "#F59E0B",         # Amber/Orange
    MILESTONE_4_PO_ISSUED: "#06B6D4",          # Cyan
    MILESTONE_5_INVOICED: "#10B981"            # Emerald/Green
}

# --- SLAs (Target Business Days for each milestone transition) ---
# Transition SLAs
SLA_TARGETS = {
    MILESTONE_1_SUBMITTED: 3,           # Time to approve by committee
    MILESTONE_2_COMMITTEE_APPROVED: 5,  # Time for user to create PR in Ariba
    MILESTONE_3_PR_CREATED: 4,          # Time for PO to be issued
    MILESTONE_4_PO_ISSUED: 7,           # Time to receive invoice and close
}

# --- PERSISTENCE (Option B - JSON file local persistence) ---
DATA_DIR = os.path.join(os.path.dirname(__file__), "data")
DATABASE_FILE = os.path.join(DATA_DIR, "procurement_data.json")
