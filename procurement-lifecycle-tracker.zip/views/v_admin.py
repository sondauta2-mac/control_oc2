# -*- coding: utf-8 -*-
"""
Procurement Lifecycle Tracker - Administration & Operations Panel
Handles creation of new procurement requests and milestone advancement for Committee/Admin.
"""

import streamlit as st
import config
from data import database
from core import tracker_engine, auth


def render_admin_panel():
    st.markdown("## ⚙️ Panel de Operaciones y Decisiones")
    
    current_role = auth.get_current_role()
    current_user = auth.get_current_user()

    # Create primary tabs depending on user role
    if current_role in [config.ROLE_COMITE, config.ROLE_ADMIN]:
        tab_create, tab_advance = st.tabs(["🆕 Crear Solicitud de Compra", "🚀 Avanzar Hitos del Ciclo"])
    else:
        tab_create = st.tabs(["🆕 Crear Solicitud de Compra"])[0]
        tab_advance = None

    # =========================================================================
    # TAB 1: CREATE REQUEST (Available to all roles)
    # =========================================================================
    with tab_create:
        st.markdown("### Registrar Nueva Solicitud de Adquisición")
        st.write("Completa los datos técnicos y comerciales para iniciar el ciclo de vida de compras:")
        
        with st.form("create_request_form", clear_on_submit=True):
            col_t, col_a = st.columns(2)
            with col_t:
                req_title = st.text_input(
                    "Descripción Corta de la Compra:", 
                    placeholder="Ej. Servidores Azure, Licencias Office, Renovar Switches"
                )
            with col_a:
                req_amount = st.number_input(
                    "Monto estimado de Compra (USD):", 
                    min_value=1.0, 
                    max_value=1000000.0, 
                    value=1000.0,
                    step=100.0
                )
                
            col_req, col_area = st.columns(2)
            with col_req:
                # Default to current user's name
                req_name = st.text_input("Nombre del Solicitante:", value=current_user["name"])
            with col_area:
                # Default to current user's area
                req_area = st.text_input("Área de la Empresa:", value=current_user["area"])
                
            req_comments = st.text_area(
                "Justificación y Comentarios Iniciales:", 
                placeholder="Explica la justificación comercial o técnica para enviar al Comité de Compras..."
            )
            
            btn_submit = st.form_submit_button("Enviar al Comité (Hito 1_SUBMITTED)")
            
            if btn_submit:
                if not req_title.strip():
                    st.error("Por favor, ingresa una descripción corta para la compra.")
                elif not req_name.strip():
                    st.error("Por favor, ingresa el nombre del solicitante.")
                elif not req_area.strip():
                    st.error("Por favor, ingresa el área de la empresa.")
                elif not req_comments.strip():
                    st.error("Por favor, agrega una justificación o comentario inicial.")
                else:
                    new_req = database.create_request(
                        title=req_title.strip(),
                        requestor=req_name.strip(),
                        area=req_area.strip(),
                        amount=req_amount,
                        comments=req_comments.strip(),
                        creator=current_user["name"]
                    )
                    st.success(f"🎉 Solicitud **{new_req['id']}** creada de forma exitosa y enviada al Comité para evaluación.")
                    st.session_state.current_search_query = new_req['id']
                    st.session_state.selected_request_details = new_req
                    st.info("Puedes ver la evolución secuencial de su hito en la pestaña **🔍 Agente de Visibilidad**.")

        if current_role == config.ROLE_SOLICITANTE:
            st.markdown("---")
            st.info(
                f"💡 **Nota de Simulación:** Como tu rol activo es **{current_role}**, una vez que envíes una solicitud, "
                "el Comité de Compras se encargará de evaluarla y registrar los hitos en SAP Ariba. "
                "Puedes alternar tu usuario a **Comité de Compras** o **Administrador General** en el menú de la izquierda para "
                "aprobar solicitudes y avanzar hitos de inmediato."
            )

    # =========================================================================
    # TAB 2: ADVANCE MILESTONES (Restricted to Comite and Admin roles)
    # =========================================================================
    if tab_advance is not None:
        with tab_advance:
            st.markdown("### Control de Avance del Ciclo de Vida")
            st.markdown(
                "Selecciona una solicitud en proceso para registrar transiciones de hitos y adjuntar referencias de SAP Ariba:"
            )

            all_reqs = database.get_all_requests()
        # Filter requests that are active (not in 5_INVOICED)
        active_reqs = [r for r in all_reqs if r["current_milestone"] != config.MILESTONE_5_INVOICED]

        if not active_reqs:
            st.info("No hay solicitudes activas pendientes por procesar.")
            return

        # Selection dropdown
        req_options = {r["id"]: f"{r['id']} - {r['title']} ({config.MILESTONE_LABELS[r['current_milestone']]})" for r in active_reqs}
        selected_id = st.selectbox(
            "Seleccionar Solicitud para avanzar:",
            options=list(req_options.keys()),
            format_func=lambda x: req_options[x]
        )

        if selected_id:
            req_to_advance = database.get_request_by_id(selected_id)
            current_milestone = req_to_advance["current_milestone"]
            next_milestone = tracker_engine.get_next_milestone(current_milestone)
            
            if next_milestone:
                current_label = config.MILESTONE_LABELS[current_milestone]
                next_label = config.MILESTONE_LABELS[next_milestone]
                
                st.markdown(
                    f"""
                    <div style="background-color: #FFFBEB; border: 1px solid #FDE68A; padding: 15px; border-radius: 6px; margin: 15px 0;">
                        Transición: <strong style="color: #D97706;">{current_label}</strong> &nbsp;➡️&nbsp; <strong style="color: #10B981;">{next_label}</strong>
                    </div>
                    """,
                    unsafe_allow_html=True
                )
                
                # Render contextual fields depending on the target milestone
                pr_num = req_to_advance.get("pr_number", "")
                po_num = req_to_advance.get("po_number", "")
                inv_num = req_to_advance.get("invoice_number", "")
                
                st.markdown("##### Campos requeridos para SAP Ariba:")
                
                col_field1, col_field2 = st.columns(2)
                with col_field1:
                    # Transition to 3_PR_CREATED requires PR Code
                    if next_milestone == config.MILESTONE_3_PR_CREATED:
                        pr_num = st.text_input(
                            "🔑 Registrar Número de PR (Ariba):", 
                            value=pr_num,
                            placeholder="PR-XXXXX (Requerido)", 
                            help="Código generado tras crear la requisición en SAP Ariba."
                        )
                    # Transition to 4_PO_ISSUED requires PO Code
                    elif next_milestone == config.MILESTONE_4_PO_ISSUED:
                        po_num = st.text_input(
                            "🔑 Registrar Número de PO (Ariba):", 
                            value=po_num,
                            placeholder="PO-XXXXX (Requerido)", 
                            help="Código generado al liberar la orden de compra."
                        )
                    # Transition to 5_INVOICED requires Invoice Code
                    elif next_milestone == config.MILESTONE_5_INVOICED:
                        inv_num = st.text_input(
                            "🔑 Registrar Número de Factura (Invoice):", 
                            value=inv_num,
                            placeholder="INV-XXXXX (Requerido)", 
                            help="Referencia de la factura del proveedor registrada para el cierre."
                        )
                    else:
                        st.info("No se requieren códigos de Ariba adicionales para esta aprobación de comité.")
                        
                with col_field2:
                    st.write("") # Padding

                comments_trans = st.text_area(
                    "Comentarios y Minuta de la Transición:", 
                    placeholder="Ingresa la bitácora o notas que justifican este cambio de estado..."
                )
                
                btn_advance = st.button("Confirmar Avance de Hito 🚀", type="primary")
                
                if btn_advance:
                    # Validations depending on target milestone
                    if next_milestone == config.MILESTONE_3_PR_CREATED and not pr_num.strip():
                        st.error("Debes ingresar el número de Solicitud de Pedido (PR) de SAP Ariba para registrar el hito 3.")
                    elif next_milestone == config.MILESTONE_4_PO_ISSUED and not po_num.strip():
                        st.error("Debes ingresar el número de Orden de Compra (PO) de SAP Ariba para liberar la compra.")
                    elif next_milestone == config.MILESTONE_5_INVOICED and not inv_num.strip():
                        st.error("Debes ingresar el número de Factura de cierre del proveedor.")
                    elif not comments_trans.strip():
                        st.error("Por favor, ingresa notas o justificación en la bitácora de la transición.")
                    else:
                        # Advance milestone
                        updated = database.update_request_milestone(
                            req_id=selected_id,
                            next_milestone=next_milestone,
                            updated_by=current_user["name"],
                            comments=comments_trans.strip(),
                            pr_num=pr_num.strip(),
                            po_num=po_num.strip(),
                            inv_num=inv_num.strip()
                        )
                        st.success(f"🎉 Solicitud **{selected_id}** avanzada exitosamente al hito: **{next_label}**.")
                        st.session_state.current_search_query = selected_id
                        st.session_state.selected_request_details = updated
                        st.info("Se ha actualizado el log de auditoría y se re-calcularon los tiempos de SLA.")
                        st.rerun()
            else:
                st.info("La solicitud seleccionada ya se encuentra en su hito de facturación y cierre final.")
