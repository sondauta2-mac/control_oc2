# -*- coding: utf-8 -*-
"""
Procurement Lifecycle Tracker - Search & LifeCycle Visibility Agent
Renders progress tracking, step visualizers, SLAs, and Ariba reference numbers.
"""

import streamlit as st
from datetime import datetime, date
import config
from data import database
from core import tracker_engine


def render_search_agent():
    st.markdown("## 🔍 Agente de Visibilidad y Seguimiento")
    st.markdown(
        "Ingresa el identificador de la solicitud para consultar su estado, tiempos de procesamiento de hitos y referencias de SAP Ariba."
    )

    # Search layout
    search_col1, search_col2 = st.columns([3, 1])
    
    with search_col1:
        search_id = st.text_input(
            "Buscar por código de solicitud (ej. RQ-1003):",
            value=st.session_state.current_search_query,
            placeholder="RQ-10XX",
            key="search_input_widget"
        )
    with search_col2:
        # Simple spacing helper to align button visually
        st.markdown("<div style='height: 28px;'></div>", unsafe_allow_html=True)
        btn_search = st.button("Buscar Solicitud", use_container_width=True)

    if btn_search or search_id:
        st.session_state.current_search_query = search_id.strip()
        req = database.get_request_by_id(st.session_state.current_search_query)
        st.session_state.selected_request_details = req
        if not req:
            st.error(f"No se encontró ninguna solicitud con el código: **{st.session_state.current_search_query}**")
            return
    else:
        req = st.session_state.selected_request_details

    # If a request is loaded
    if req:
        ana = tracker_engine.analyze_request_sla(req)
        
        # --- TITLE & GENERAL OVERVIEW CARD ---
        st.markdown("---")
        
        is_delayed_str = "🔴 Fuera de SLA" if ana["is_delayed"] else "🟢 Dentro de SLA"
        
        st.markdown(
            f"""
            <div style="background-color: #F8FAFC; border: 1px solid #E2E8F0; padding: 20px; border-radius: 8px; margin-bottom: 25px;">
                <div style="display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap;">
                    <h3 style="margin: 0; color: #1E293B; font-size: 1.5em;">{req['id']} - {req['title']}</h3>
                    <span style="background-color: {'#FEF2F2' if ana['is_delayed'] else '#ECFDF5'}; 
                                 color: {'#DC2626' if ana['is_delayed'] else '#10B981'}; 
                                 font-weight: bold; padding: 4px 12px; border-radius: 9999px; font-size: 0.9em; margin-top: 5px;">
                        {is_delayed_str}
                    </span>
                </div>
                <div style="margin-top: 15px; font-size: 0.95em; color: #475569; display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 10px;">
                    <div>Solicitante: <strong>{req['requestor']}</strong></div>
                    <div>Área: <strong>{req['area']}</strong></div>
                    <div>Monto: <strong style="color: #0F172A;">${req['amount']:,.2f} USD</strong></div>
                    <div>Fecha de Creación: <strong>{req['created_at']}</strong></div>
                </div>
            </div>
            """,
            unsafe_allow_html=True
        )

        # --- ARIBA CODES CARDS ---
        st.markdown("### 📎 Referencias y Documentos en SAP Ariba")
        ar_col1, ar_col2, ar_col3 = st.columns(3)
        with ar_col1:
            pr_val = req["pr_number"] if req["pr_number"] else "⚠️ No creado"
            st.markdown(
                f"""
                <div style="border: 1px solid #E2E8F0; border-radius: 6px; padding: 12px; background-color: #FFF; text-align: center;">
                    <p style="margin: 0; color: #64748B; font-size: 0.85em; font-weight: 500;">Solicitud de Pedido (PR)</p>
                    <p style="margin: 5px 0 0 0; font-family: monospace; font-size: 1.15em; font-weight: bold; color: {'#0F172A' if req['pr_number'] else '#D97706'};">{pr_val}</p>
                </div>
                """,
                unsafe_allow_html=True
            )
        with ar_col2:
            po_val = req["po_number"] if req["po_number"] else "⚠️ No liberado"
            st.markdown(
                f"""
                <div style="border: 1px solid #E2E8F0; border-radius: 6px; padding: 12px; background-color: #FFF; text-align: center;">
                    <p style="margin: 0; color: #64748B; font-size: 0.85em; font-weight: 500;">Orden de Compra (PO)</p>
                    <p style="margin: 5px 0 0 0; font-family: monospace; font-size: 1.15em; font-weight: bold; color: {'#0F172A' if req['po_number'] else '#D97706'};">{po_val}</p>
                </div>
                """,
                unsafe_allow_html=True
            )
        with ar_col3:
            inv_val = req["invoice_number"] if req["invoice_number"] else "⚠️ No cargada"
            st.markdown(
                f"""
                <div style="border: 1px solid #E2E8F0; border-radius: 6px; padding: 12px; background-color: #FFF; text-align: center;">
                    <p style="margin: 0; color: #64748B; font-size: 0.85em; font-weight: 500;">Factura del Proveedor</p>
                    <p style="margin: 5px 0 0 0; font-family: monospace; font-size: 1.15em; font-weight: bold; color: {'#0F172A' if req['invoice_number'] else '#D97706'};">{inv_val}</p>
                </div>
                """,
                unsafe_allow_html=True
            )

        # --- SEQUENTIAL FLOW PIPELINE (PROGRESS TRACKER) ---
        st.markdown("<div style='margin-top: 30px;'></div>", unsafe_allow_html=True)
        st.markdown("### 🗺️ Mapa del Ciclo de Vida del Abastecimiento")
        st.write("Evolución secuencial de hitos y tiempos reales vs. SLA límite:")

        milestone_dates = ana["milestone_dates"]
        current_idx = config.MILESTONES.index(req["current_milestone"])

        # Display milestones linearly with beautiful custom timeline
        for i, m in enumerate(config.MILESTONES):
            is_completed = i < current_idx
            is_active = m == req["current_milestone"]
            is_future = i > current_idx
            
            label = config.MILESTONE_LABELS[m]
            desc = config.MILESTONE_DESCRIPTIONS[m]
            m_color = config.MILESTONE_COLORS[m]
            
            # Retrieve date if recorded
            m_date_str = milestone_dates.get(m).strftime("%Y-%m-%d") if m in milestone_dates else ""
            
            # Compute days spent details
            sla_details = ""
            bg_color = "#FFF"
            border_style = "1px solid #E2E8F0"
            
            if is_completed:
                bg_color = "#F0FDF4" # Soft green
                border_style = "2px solid #10B981"
                # Find days spent in this completed milestone
                timeline_match = [t for t in ana["timeline"] if t["milestone"] == m]
                if timeline_match:
                    days = timeline_match[0]["days_spent"]
                    target = timeline_match[0]["target_days"]
                    breached = timeline_match[0]["is_breached"]
                    badge_color = "#EF4444" if breached else "#10B981"
                    badge_text = "Retraso" if breached else "Cumplido"
                    sla_details = f'<span style="background-color: {badge_color}15; color: {badge_color}; border: 1px solid {badge_color}30; padding: 2px 8px; border-radius: 4px; font-size: 0.8em; font-weight: bold; margin-left: 10px;">{badge_text} ({days}/{target} días hábiles)</span>'
            elif is_active:
                if m == config.MILESTONE_5_INVOICED:
                    # Final closed milestone
                    bg_color = "#ECFDF5"
                    border_style = "2px solid #059669"
                    sla_details = '<span style="background-color: #ECFDF5; color: #059669; border: 1px solid #05966930; padding: 2px 8px; border-radius: 4px; font-size: 0.8em; font-weight: bold; margin-left: 10px;">Completado y Cerrado</span>'
                else:
                    # Active and in progress
                    is_delayed = ana["is_delayed"]
                    bg_color = "#FEF2F2" if is_delayed else "#EFF6FF"
                    border_style = f"2px solid {'#EF4444' if is_delayed else '#3B82F6'}"
                    days = ana["current_sla"]["days_spent"] if ana["current_sla"] else 0
                    target = ana["current_sla"]["target_days"] if ana["current_sla"] else 0
                    remaining = ana["current_sla"]["remaining_days"] if ana["current_sla"] else 0
                    
                    if is_delayed:
                        sla_details = f'<span style="background-color: #FEF2F2; color: #DC2626; border: 1px solid #EF4444; padding: 2px 8px; border-radius: 4px; font-size: 0.8em; font-weight: bold; margin-left: 10px;">Vencido (+{days - target} días extra)</span>'
                    else:
                        sla_details = f'<span style="background-color: #EFF6FF; color: #2563EB; border: 1px solid #3B82F6; padding: 2px 8px; border-radius: 4px; font-size: 0.8em; font-weight: bold; margin-left: 10px;">En Curso ({days}/{target} días | {remaining} restan)</span>'
            else:
                # Future milestone
                bg_color = "#F8FAFC"
                border_style = "1px dashed #CBD5E1"
                sla_details = '<span style="color: #94A3B8; font-size: 0.85em; margin-left: 10px;">Pendiente</span>'

            status_icon = "✅" if is_completed else ("⏳" if is_active else "🔒")
            if is_active and m == config.MILESTONE_5_INVOICED:
                status_icon = "🏆"
                
            # Render a single-line block of HTML to completely bypass any Markdown block-code formatting bugs
            timeline_html = (
                f'<div style="background-color: {bg_color}; border: {border_style}; border-radius: 8px; padding: 15px; margin-bottom: 12px; display: flex; align-items: flex-start; gap: 15px;">'
                f'  <div style="font-size: 1.4em; background-color: {m_color}15; padding: 8px; border-radius: 6px; display: flex; align-items: center; justify-content: center; width: 42px; height: 42px;">{status_icon}</div>'
                f'  <div style="flex-grow: 1;">'
                f'    <div style="display: flex; justify-content: space-between; flex-wrap: wrap; align-items: center;">'
                f'      <strong style="color: #0F172A; font-size: 1.05em;">{label}</strong>'
                f'      <div style="display: flex; align-items: center; gap: 10px;">'
                f'        <span style="font-family: monospace; font-size: 0.85em; color: #475569;">{m_date_str}</span>'
                f'        {sla_details}'
                f'      </div>'
                f'    </div>'
                f'    <p style="margin: 5px 0 0 0; font-size: 0.9em; color: #64748B; line-height: 1.4;">{desc}</p>'
                f'  </div>'
                f'</div>'
            )
            st.markdown(timeline_html, unsafe_allow_html=True)

        # --- LOG HISTORY TABLE ---
        st.markdown("<div style='margin-top: 30px;'></div>", unsafe_allow_html=True)
        st.markdown("### 📑 Historial de Operaciones y Bitácora")
        
        history_rows = []
        for h in reversed(req["history"]):
            history_rows.append({
                "Fecha": h.get("updated_at"),
                "Hito": config.MILESTONE_LABELS.get(h.get("milestone"), h.get("milestone")),
                "Registrado Por": h.get("updated_by"),
                "Comentarios / Bitácora": h.get("comments", "-")
            })
            
        st.dataframe(history_rows, use_container_width=True, hide_index=True)

        # --- Q&A SEARCH VISIBILITY AGENT CHAT ---
        st.markdown("<div style='margin-top: 35px;'></div>", unsafe_allow_html=True)
        st.markdown("### 🤖 Preguntar al Agente de Compras")
        st.markdown(
            "Consulta datos o proyecciones sobre esta solicitud usando el agente interno de visibilidad:"
        )
        
        qa_query = st.text_input(
            "Haz una pregunta sobre esta compra (ej: ¿Cuándo se aprobó? o ¿Hay retraso?):",
            placeholder="Escribe tu consulta aquí..."
        )
        
        if qa_query:
            query_clean = qa_query.lower()
            with st.spinner("Analizando ciclo de vida..."):
                answer = ""
                # Parse queries intelligently using metadata
                if "aprob" in query_clean:
                    ap_hist = [h for h in req["history"] if h["milestone"] == config.MILESTONE_2_COMMITTEE_APPROVED]
                    if ap_hist:
                        answer = f"La solicitud **{req['id']}** fue aprobada por el comité el día **{ap_hist[0]['updated_at']}** por **{ap_hist[0]['updated_by']}** con el siguiente comentario: *\"{ap_hist[0]['comments']}\"*."
                    else:
                        answer = f"La solicitud **{req['id']}** todavía no ha sido aprobada por el comité. Actualmente se encuentra en el hito **{config.MILESTONE_LABELS[req['current_milestone']]}**."
                elif "retras" in query_clean or "sla" in query_clean or "demor" in query_clean or "venc" in query_clean:
                    if ana["is_delayed"]:
                        days = ana["current_sla"]["days_spent"]
                        target = ana["current_sla"]["target_days"]
                        answer = f"Sí, la solicitud **{req['id']}** presenta un retraso de **{days - target}** días hábiles en el hito actual **{config.MILESTONE_LABELS[req['current_milestone']]}**. Lleva **{days}** días hábiles de un límite permitido de **{target}**."
                    else:
                        answer = f"No, la solicitud **{req['id']}** se encuentra al día y en cumplimiento del SLA. Para el hito actual (**{config.MILESTONE_LABELS[req['current_milestone']]}**), lleva **{ana['current_sla']['days_spent'] if ana['current_sla'] else 0}** días hábiles consumidos de un límite de **{ana['current_sla']['target_days'] if ana['current_sla'] else 0}** días."
                elif "monto" in query_clean or "precio" in query_clean or "cost" in query_clean or "valor" in query_clean:
                    answer = f"El monto registrado para esta adquisición es de **${req['amount']:,.2f} USD**."
                elif "pr" in query_clean or "ariba" in query_clean:
                    if req["pr_number"]:
                        answer = f"El número de Solicitud de Pedido (PR) en SAP Ariba es **{req['pr_number']}**."
                    else:
                        answer = f"El PR de Ariba aún no ha sido registrado. El usuario puede crearlo una vez que la solicitud sea aprobada por el comité."
                elif "po" in query_clean or "orden" in query_clean:
                    if req["po_number"]:
                        answer = f"La Orden de Compra (PO) en SAP Ariba ha sido liberada con el número **{req['po_number']}**."
                    else:
                        answer = f"La Orden de Compra (PO) aún no ha sido liberada. El hito actual es **{config.MILESTONE_LABELS[req['current_milestone']]}**."
                elif "factur" in query_clean or "invoice" in query_clean:
                    if req["invoice_number"]:
                        answer = f"La factura asociada es la **{req['invoice_number']}**. El ciclo de vida de esta compra ya está completamente cerrado."
                    else:
                        answer = f"Aún no se ha registrado factura del proveedor. Este paso se realiza como hito de cierre definitivo."
                else:
                    # Generic response combining all knowledge
                    answer = f"La solicitud **{req['id']}** (*{req['title']}*) tiene un valor de **${req['amount']:,.2f} USD**, fue creada el **{req['created_at']}** y se encuentra actualmente en el hito **{config.MILESTONE_LABELS[req['current_milestone']]}**. Su estado actual de cumplimiento es **{is_delayed_str}**."
                
                st.markdown(
                    f"""
                    <div style="background-color: #F0FDF4; border-left: 5px solid #10B981; padding: 15px; border-radius: 4px; margin-top: 10px;">
                        <span style="font-weight: bold; color: #065F46;">🤖 Visibilidad AI responde:</span><br/>
                        <span style="color: #047857; font-size: 0.95em;">{answer}</span>
                    </div>
                    """,
                    unsafe_allow_html=True
                )
    else:
        if st.session_state.current_search_query:
            st.info("Ingresa un código de solicitud válido para comenzar.")
        else:
            st.info("💡 Consejo: Puedes seleccionar directamente una solicitud de la tabla en el **📊 Panel de Control** o ingresar su código para rastrearla.")
