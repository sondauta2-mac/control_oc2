# -*- coding: utf-8 -*-
"""
Procurement Lifecycle Tracker - Dashboard View
Main overview screen with high-level KPIs, active alerts, and charts.
"""

import streamlit as st
import pandas as pd
import config
from data import database
from core import tracker_engine, auth


def render_dashboard():
    st.markdown(f"## 📊 Panel de Control y KPIs")
    
    # Get current session info
    current_role = auth.get_current_role()
    current_user = auth.get_current_user()
    
    # Load fresh data
    all_reqs = database.get_all_requests()
    
    if not all_reqs:
        st.warning("No hay solicitudes registradas en el sistema.")
        return

    # Adapt visibility and render helpful context banner depending on the active role
    if current_role == config.ROLE_SOLICITANTE:
        st.info(
            f"👁️ **Vista Limitada (Rol: Solicitante):** Estás visualizando únicamente las solicitudes registradas a nombre de **{current_user['name']}** ({current_user['area']}). "
            f"El resto de la información y solicitudes corporativas de otros usuarios está oculta de forma segura para tu rol."
        )
        # Filter to only show current user's requests
        all_reqs = [r for r in all_reqs if r["requestor"].lower() == current_user["name"].lower()]
    elif current_role == config.ROLE_COMITE:
        st.success(
            f"🔑 **Acceso Corporativo (Rol: Comité de Compras):** Estás visualizando todas las métricas de la organización. "
            f"Como miembro del Comité, puedes auditar todas las solicitudes y realizar aprobaciones de hitos."
        )
    elif current_role == config.ROLE_ADMIN:
        st.success(
            f"⚡ **Acceso Total (Rol: Administrador General):** Estás visualizando toda la información corporativa. "
            f"Tienes permisos de modificación absoluta sobre todo el ciclo de vida de compras."
        )

    # In case the filtered list is empty for a newly switched user
    if not all_reqs:
        st.warning(f"No hay solicitudes registradas para el usuario **{current_user['name']}**.")
        return

    # Calculate KPIs on the filtered (or complete) data
    kpis = tracker_engine.calculate_dashboard_kpis(all_reqs)

    # --- TOP KPI METRICS ---
    col1, col2, col3, col4 = st.columns(4)
    
    with col1:
        st.metric(
            label="Total Solicitudes", 
            value=kpis["total_requests"], 
            help="Histórico completo de solicitudes registradas"
        )
        
    with col2:
        st.metric(
            label="En Proceso (Activas)", 
            value=kpis["active_requests"],
            help="Solicitudes que aún no han sido facturadas"
        )
        
    with col3:
        # Style delayed count with custom color warning
        color_flag = "🔴" if kpis["delayed_active_requests"] > 0 else "🟢"
        st.metric(
            label=f"{color_flag} Con Retraso SLA", 
            value=kpis["delayed_active_requests"],
            delta=f"{kpis['delayed_active_requests']} críticas" if kpis["delayed_active_requests"] > 0 else "0 críticas",
            delta_color="inverse",
            help="Solicitudes activas que excedieron los días hábiles del hito actual"
        )
        
    with col4:
        # SLA adherence rate
        sla_val = f"{kpis['sla_on_time_percentage']:.1f}%"
        st.metric(
            label="Cumplimiento de SLA", 
            value=sla_val,
            help="Porcentaje de transiciones de hitos completadas a tiempo"
        )

    # --- ALERTS SECTION ---
    st.markdown("---")
    if kpis["alerts"]:
        st.markdown("### ⚠️ Alertas Críticas de Retraso")
        st.write("Las siguientes solicitudes han superado el tiempo límite permitido en su hito actual:")
        
        for alert in kpis["alerts"]:
            with st.container():
                st.markdown(
                    f"""
                    <div style="background-color: #FEF2F2; border-left: 5px solid #EF4444; padding: 12px; border-radius: 4px; margin-bottom: 10px;">
                        <span style="font-weight: bold; color: #991B1B;">{alert['id']} - {alert['title']}</span><br/>
                        <span style="font-size: 0.9em; color: #7F1D1D;">
                            Hito Actual: <strong>{alert['current_milestone_label']}</strong> | 
                            Días Transcurridos: <span style="font-weight: bold; color: #DC2626;">{alert['days_spent']} días hábiles</span> 
                            (Límite SLA: {alert['target_days']} días) | 
                            Solicitante: <strong>{alert['requestor']}</strong>
                        </span>
                    </div>
                    """,
                    unsafe_allow_html=True
                )
                # Quick-view button inside streamlit columns to not break HTML layout
                c1, c2 = st.columns([6, 1])
                with c2:
                    if st.button(f"Ver {alert['id']}", key=f"alert_btn_{alert['id']}"):
                        st.session_state.current_search_query = alert['id']
                        st.session_state.selected_request_details = database.get_request_by_id(alert['id'])
                        st.rerun()
        st.markdown("<div style='height: 10px;'></div>", unsafe_allow_html=True)
    else:
        st.success("🎉 Todas las solicitudes activas se encuentran dentro del SLA objetivo.")

    # --- CHARTS SECTION (BENTO GRID) ---
    st.markdown("---")
    st.markdown("### 📈 Distribución y Rendimiento")
    chart_col1, chart_col2 = st.columns(2)

    with chart_col1:
        st.markdown("**Solicitudes por Hito del Ciclo de Vida**")
        # Build pandas df for bar chart
        m_dist = kpis["milestone_distribution"]
        # Map labels
        m_data = {config.MILESTONE_LABELS[m]: m_dist[m] for m in config.MILESTONES}
        df_milestones = pd.DataFrame(list(m_data.items()), columns=["Hito", "Cantidad"])
        
        # Streamlit bar chart
        st.bar_chart(df_milestones.set_index("Hito"), height=250)

    with chart_col2:
        st.markdown("**Días Promedio del Ciclo y Eficiencia**")
        # Let's show avg cycle time card and a tiny table of SLAs
        st.markdown(
            f"""
            <div style="background-color: #F8FAFC; border: 1px solid #E2E8F0; padding: 16px; border-radius: 8px; text-align: center; margin-bottom: 15px;">
                <p style="margin: 0; color: #64748B; font-size: 0.95em;">Ciclo de Vida Promedio (Cerrados)</p>
                <h2 style="margin: 5px 0; color: #0F172A; font-size: 2.2em;">{kpis['avg_cycle_days']:.1f} <span style="font-size: 0.5em;">días hábiles</span></h2>
                <p style="margin: 0; color: #10B981; font-size: 0.85em; font-weight: bold;">Desde Creación hasta Facturación</p>
            </div>
            """, 
            unsafe_allow_html=True
        )
        
        # Display SLA Limits Table
        df_slas = pd.DataFrame([
            {"Hito": config.MILESTONE_LABELS[m], "SLA Límite (Días Hábiles)": config.SLA_TARGETS[m]}
            for m in config.SLA_TARGETS
        ])
        st.dataframe(df_slas, hide_index=True, use_container_width=True)

    # --- ACTIVE REQUESTS LIST ---
    st.markdown("---")
    st.markdown("### 📋 Listado General de Solicitudes Activas")
    
    active_reqs_data = [r for r in all_reqs if r["current_milestone"] != config.MILESTONE_5_INVOICED]
    
    if active_reqs_data:
        # Build tabular data
        rows = []
        for r in active_reqs_data:
            ana = tracker_engine.analyze_request_sla(r)
            days_spent = ana["current_sla"]["days_spent"] if ana["current_sla"] else 0
            limit = ana["current_sla"]["target_days"] if ana["current_sla"] else 0
            status_sla = "⚠️ Fuera de SLA" if ana["is_delayed"] else "✅ En SLA"
            
            rows.append({
                "Código": r["id"],
                "Descripción": r["title"],
                "Solicitante": r["requestor"],
                "Monto (USD)": f"${r['amount']:,.2f}",
                "Hito Actual": config.MILESTONE_LABELS.get(r["current_milestone"]),
                "Días en Hito": days_spent,
                "Límite SLA": limit,
                "Estado SLA": status_sla
            })
            
        df_active = pd.DataFrame(rows)
        st.dataframe(df_active, use_container_width=True, hide_index=True)
        
        # Select active request to inspect
        selected_code = st.selectbox(
            "Seleccionar una solicitud para ver detalle en el Agente de Visibilidad:", 
            options=[""] + [r["id"] for r in active_reqs_data],
            format_func=lambda x: f"{x} - {database.get_request_by_id(x)['title']}" if x else "Seleccione una solicitud..."
        )
        
        if selected_code:
            st.session_state.current_search_query = selected_code
            st.session_state.selected_request_details = database.get_request_by_id(selected_code)
            st.info(f"Solicitud {selected_code} seleccionada. Ve a la pestaña **🔍 Agente de Visibilidad** para interactuar.")
    else:
        st.info("No hay solicitudes activas en curso.")
