# -*- coding: utf-8 -*-
"""
Procurement Lifecycle Tracker - App Router
Main entry point for the Streamlit application.
Configures page layouts, sidebar mock auth selectors, and tabs.
"""

import streamlit as st

# --- PAGE CONFIGURATION ---
# Must be called as the very first Streamlit command
st.set_page_config(
    page_title="Procurement Lifecycle Tracker",
    page_icon="📦",
    layout="wide",
    initial_sidebar_state="expanded"
)

import config
from core import auth
from views import v_dashboard, v_search, v_admin

# --- INITIALIZE SESSION STATE ---
auth.init_session_state()

# --- SIDEBAR: CONTROLS & AUTH SELECTOR ---
with st.sidebar:
    st.markdown(
        f"""
        <div style="text-align: center; padding: 10px 0; border-bottom: 2px solid #E2E8F0; margin-bottom: 20px;">
            <h2 style="color: #1E3A8A; margin: 0; font-size: 1.6em;">📦 PLT</h2>
            <p style="color: #64748B; font-size: 0.85em; margin: 5px 0 0 0; font-weight: bold;">
                Procurement Lifecycle Tracker
            </p>
        </div>
        """,
        unsafe_allow_html=True
    )
    
    st.markdown("### 👥 Control de Sesión (Simulador)")
    st.write(
        "Como esta es una POC, puedes alternar de usuario de forma instantánea para probar los diferentes flujos y permisos de cada rol:"
    )
    
    # Locate index of current user to keep selection synced
    current_username = st.session_state.current_user["username"]
    user_names = [u["name"] for u in auth.MOCK_USERS]
    user_idx = 0
    for idx, u in enumerate(auth.MOCK_USERS):
        if u["username"] == current_username:
            user_idx = idx
            break
            
    selected_user_name = st.selectbox(
        "Seleccionar Usuario Activo:",
        options=user_names,
        index=user_idx,
        key="mock_auth_dropdown"
    )
    
    # Update state if changed
    selected_user_dict = next(u for u in auth.MOCK_USERS if u["name"] == selected_user_name)
    if selected_user_dict["username"] != current_username:
        auth.set_user_session(selected_user_dict)
        st.rerun()

    # Visual user profile card
    st.markdown(
        f"""
        <div style="background-color: #F8FAFC; border: 1px solid #E2E8F0; border-radius: 6px; padding: 15px; margin: 15px 0 25px 0;">
            <p style="margin: 0; font-size: 0.8em; text-transform: uppercase; letter-spacing: 0.05em; color: #64748B; font-weight: bold;">Perfil Activo</p>
            <p style="margin: 5px 0 0 0; font-weight: bold; color: #0F172A; font-size: 1.05em;">{st.session_state.current_user['name']}</p>
            <p style="margin: 2px 0 0 0; font-size: 0.85em; color: #475569;">Área: <strong>{st.session_state.current_user['area']}</strong></p>
            <div style="margin-top: 8px; display: inline-block; background-color: #DBEAFE; color: #1E40AF; font-size: 0.75em; padding: 2px 8px; border-radius: 4px; font-weight: bold;">
                Rol: {st.session_state.user_role}
            </div>
        </div>
        """,
        unsafe_allow_html=True
    )
    
    st.markdown("---")
    st.markdown("### 🏢 Datos de Soporte & SPOC")
    st.markdown(
        f"""
        <div style="font-size: 0.9em; color: #475569;">
            <p style="margin: 0 0 5px 0;">🧑‍💼 SPOC Principal: <strong>{config.SPOC}</strong></p>
            <p style="margin: 0 0 5px 0;">🌐 Plataforma: <strong>Streamlit Web</strong></p>
            <p style="margin: 0 0 5px 0;">🗃️ Base de Datos: <strong>Local JSON (Persistente)</strong></p>
            <p style="margin: 0 0 5px 0;">⏱️ Zona Horaria: <strong>Local</strong></p>
        </div>
        """,
        unsafe_allow_html=True
    )

# --- MAIN PAGE PANEL ---
st.markdown(
    f"""
    <div style="background-color: #1E3A8A; color: white; padding: 20px; border-radius: 8px; margin-bottom: 25px;">
        <h1 style="color: white; margin: 0; font-size: 2.2em; font-weight: bold;">📦 {config.APP_NAME}</h1>
        <p style="margin: 5px 0 0 0; font-size: 1.1em; color: #93C5FD;">{config.APP_SUBTITLE}</p>
    </div>
    """,
    unsafe_allow_html=True
)

# Render major tabs for navigation
tab_dash, tab_search, tab_admin = st.tabs([
    "📊 Panel de Control (KPIs)", 
    "🔍 Agente de Visibilidad", 
    "⚙️ Panel de Operaciones"
])

with tab_dash:
    v_dashboard.render_dashboard()

with tab_search:
    v_search.render_search_agent()

with tab_admin:
    v_admin.render_admin_panel()
